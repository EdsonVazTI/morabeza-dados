"""Pipelines ETL da Morabeza."""
